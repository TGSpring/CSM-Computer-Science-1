//And class tests two terms to see if their is an AND relationship.
class And: public SubExpression
{
public:
    And(Expression* left, Expression* right):
        SubExpression(left, right)
    {
    }
    double evaluate()
    {
       return left->evaluate() && right->evaluate();
    }
};
