//This is the equals class. Here the terms are tested to see if they are equal to each other.
class Equal: public SubExpression
{
public:
    Equal(Expression* left, Expression* right):
        SubExpression(left, right)
    {
    }
    double evaluate()
    {
       return left->evaluate() == right->evaluate();
    }
};