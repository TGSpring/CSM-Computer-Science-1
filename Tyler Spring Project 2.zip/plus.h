//Adds the right term to the left term when + is found.
class Plus : public SubExpression
{
public:
    Plus(Expression* left, Expression* right) : SubExpression(left, right)
    {
    }
    double evaluate()
    {
        return left->evaluate() + right->evaluate();
    }
};