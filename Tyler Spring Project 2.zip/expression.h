//Here the expression class is simply defined using a virtual function to limit errors of multiple inheritance.
class Expression
{
public:
    virtual double evaluate() = 0;
};