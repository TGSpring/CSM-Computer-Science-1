//Two terms are tested to see if the left term is less than the other when a < is found.
class LessThan: public SubExpression
{
public:
    LessThan(Expression* left, Expression* right):
        SubExpression(left, right)
    {
    }
    double evaluate()
    {
       return left->evaluate() < right->evaluate();
    }
};