//defines parser class.
string parseName();