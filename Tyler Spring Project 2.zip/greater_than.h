//Two terms are tested to see if the left term is greater than the other when a > is found.
class GreaterThan: public SubExpression
{
public:
    GreaterThan(Expression* left, Expression* right):
        SubExpression(left, right)
    {
    }
    double evaluate()
    {
       return left->evaluate() > right->evaluate();
    }
};