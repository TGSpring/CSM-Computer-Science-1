//The subexpression class is used to identify and assign the terms of an equation then uses a case statement to assign a 
//a function to be preformed on it.
#include <iostream>
#include <sstream>
using namespace std;

#include "expression.h"
#include "subexpression.h"
#include "operand.h"
#include "plus.h"
#include "minus.h"
#include "times.h"
#include "divide.h"
#include "greater_than.h"
#include "less_than.h"
#include "equal.h"
#include "and.h"
#include "or.h"
#include "TernCond.h"
#include "literal.h"
#include "negation.h"


SubExpression::SubExpression(Expression* left, Expression* right)
{
    this->left = left;
    this->right = right;
}
SubExpression::SubExpression(Expression* left, Expression* right, Expression* condition)
{
    this->left = left;
    this->right = right;
    this->condition = condition;
}
SubExpression::SubExpression(Expression* left) {
    this->left = left;
}
Expression* SubExpression::parse()
{
    Expression* left;
    Expression* right;
    Expression* condition;
    char operation, paren, third;

    left = Operand::parse();
    cin >> operation;
    if (operation == '!') {
        cin >> paren;
        return new Negation(left);
    }
    else if (operation == ':') {
        right = Operand::parse();
        cin >> third;
        condition = Operand::parse();
        cin >> paren;
        return new TernCond(left, right, condition);
    }
    else {
        right = Operand::parse();
        cin >> paren;
    }
    switch (operation)
    {
    case '+':
        return new Plus(left, right);
    case '-':
        return new Minus(left, right);
    case '*':
        return new Times(left, right);
    case '/':
        return new Divide(left, right);

    case '>':
        return new GreaterThan(left, right);
    case '<':
        return new LessThan(left, right);
    case '|':
        return new Or(left, right);
    case '&':
        return new And(left, right);
    case '=':
        return new Equal(left, right);
    }
    return 0;
}
