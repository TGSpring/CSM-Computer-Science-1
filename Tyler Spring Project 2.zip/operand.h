//Defines the operand class by inheriting the expression class.
class Operand : public Expression
{
public:
    static Expression* parse();
};

