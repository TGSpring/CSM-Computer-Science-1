//This is the divide class. Here division is performed on the given left and right terms.
class Divide: public SubExpression
{
public:
    Divide(Expression* left, Expression* right):
        SubExpression(left, right)
    {
    }
    double evaluate()
    {
       return left->evaluate() / right->evaluate();
    }
};