/*
* Tyler Spring
* project 2
* The purpose of this program is take a text file and create a binary tree.
* From this tree the program preforms different functions based on the provided grammar.
* These operations are decided based on what characters/operators are in the file. Once the file is fully read
* and all the calculations are done, it outputs the file with the results for each function.
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

#include "expression.h"
#include "subexpression.h"
#include "symboltable.h"
#include "parse.h"

SymbolTable symbolTable;

void parseAssignments();

int main()
{
    ifstream myfile("input.txt");
    Expression* expression;
    char paren, comma;
    string program;
    try {
        if (myfile.is_open()) {
            while (getline(myfile, program))
            {
                stringstream in(program, ios_base::in);
                cin >> paren;
                expression = SubExpression::parse();
                cin >> comma;
                parseAssignments();
                double result = expression->evaluate();
                cout << "Value = " << result << endl;
                myfile.close();
            }
        }
        else {
            throw 505;
        }
    }
    catch (int num) {
        cout << "File not found.";
    }
   
    return 0;
}

void parseAssignments()
{
    char assignop, delimiter;
    string variable;
    double value;
    do
    {
        variable = parseName();
        cin >> ws >> assignop >> value >> delimiter;
        symbolTable.insert(variable, value);
    } while (delimiter == ',');
}