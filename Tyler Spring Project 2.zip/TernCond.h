//Here a conditional relationship is tested.
class TernCond: public SubExpression
{
public:
    TernCond(Expression* left, Expression* right, Expression* condition):
        SubExpression(left, right, condition)
    {
    }
    double evaluate()
    {
          if (condition->evaluate()) {
            return left->evaluate();
        }
        return right->evaluate();
    
    }
};