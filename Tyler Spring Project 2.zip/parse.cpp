//This is th parser class. Here the parseName method is used to peek the new string.
#include <cctype>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

#include "parse.h"

string parseName()
{
    char alnum;
    string name = "";

    cin >> ws;
    while (isalnum(cin.peek()))
    {
        cin >> alnum;
        name += alnum;
    }
    return name;
}